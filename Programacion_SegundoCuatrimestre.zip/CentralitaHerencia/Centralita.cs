﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Centralita 
    {
        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas
        }

        private List<Llamada> listaDeLlamadas;
        protected string razonSocial;

        private float GananciasPorLocal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLLamada.Local);
            }
        }
        private float GananciasPorProvincial
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLLamada.Provincial);
            }
        }
        public float GananciasPorTotal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLLamada.Todas);
            }
        }

        public List<Llamada> Llamadas
        {
            get
            {
                return this.listaDeLlamadas;
            }
        }

        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamada>();
        }

        public Centralita (string nombreEmpresa) :this()
        {
            this.razonSocial = nombreEmpresa;
        }

        private float CalcularGanancia (Llamada.TipoLLamada tipo) 
        {
            float retorno = 0;
                   

            foreach (Llamada call in listaDeLlamadas)
            {
                //(tipo.GetType() == typeof(CentralitaHerencia.Local)
                if ((tipo == Llamada.TipoLLamada.Local || tipo == Llamada.TipoLLamada.Todas) && call is Local)  // modifique el que diga solo Local por CentralitaHerencia.Local      
                {
                    retorno += call.Duracion * ((Local)call).CostoLlamada;                         // porque cuando entra GetType lee eso CentralitaHerencia.Local
                }
                else if ((tipo == Llamada.TipoLLamada.Provincial || tipo == Llamada.TipoLLamada.Todas )&& call is Provincial)//(tipo.GetType() == typeof(CentralitaHerencia.Provincial))

                {
                    retorno += ((Provincial)call).CostoLlamada;
                }
              
            }             
            
            return retorno;
        }

        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            string aux = "";
            sb.AppendFormat("{0}{1}{2}{3}", razonSocial, GananciasPorTotal, GananciasPorLocal, GananciasPorProvincial);
            foreach (Llamada call in listaDeLlamadas)
            {
                if(call is Local)
                {
                    caux = ((Local)call).
                }
            }
            sb.AppendLine("HOLA");
            return sb.ToString();
        }

        public void OrdenarLlamadas ()
        {
            this.listaDeLlamadas.Sort(Llamada.OrdenarPorDuracion); 
        }
    }
}
